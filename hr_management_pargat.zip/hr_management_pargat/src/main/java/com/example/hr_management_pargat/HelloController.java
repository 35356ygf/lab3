package com.example.hr_management_pargat;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;


public class HelloController {
    public TextField username;
    public TextField password;
    public Button login;
    @FXML
    private Label welcomeText;


    @FXML
    protected void onHelloButtonClick() {



        try {

            Parent secondScene = FXMLLoader.load(getClass().getResource("dashboard.fxml"));

            Stage secondStage = new Stage();
            secondStage.setTitle("User Scene");
            secondStage.setScene(new Scene(secondScene));

            Stage firstSceneStage = (Stage) login.getScene().getWindow();
            firstSceneStage.close();



            secondStage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
    }

