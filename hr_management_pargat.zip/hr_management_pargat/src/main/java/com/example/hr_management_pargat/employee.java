package com.example.hr_management_pargat;


import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;

import java.net.URL;
import java.sql.*;
import java.util.ResourceBundle;

public class EmployeeController implements Initializable {

    @FXML
    private TableView<EmployeeController> employeeTable;
    @FXML
    private TableColumn<EmployeeController, Integer> employeeid;
    @FXML
    private TableColumn<Employee, String> employeename;
    @FXML
    private TableColumn<Employee, String> employeeemail;
    @FXML
    private TableColumn<Employee, String> employeemobile;
    @FXML
    private TextField employeeIdField;
    @FXML
    private TextField employeeNameField;
    @FXML
    private TextField employeeEmailField;
    @FXML
    private TextField employeeMobileField;

    private ObservableList<Employee> employeeList = FXCollections.observableArrayList();

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        employeeid.setCellValueFactory(new PropertyValueFactory<>("employeeid"));
        employeename.setCellValueFactory(new PropertyValueFactory<>("employeename"));
        employeeemail.setCellValueFactory(new PropertyValueFactory<>("employeeemail"));
        employeemobile.setCellValueFactory(new PropertyValueFactory<>("employeemobile"));

        employeeTable.setItems(employeeList);
        fetchEmployeeData(); // Fetch data on initialization
    }

    @FXML
    protected void fetchEmployeeData() {
        employeeList.clear();

        String jdbcUrl = "jdbc:mysql://localhost:3306/lab3";
        String dbUser = "root";
        String dbPassword = "";

        try (Connection connection = DriverManager.getConnection(jdbcUrl, dbUser, dbPassword)) {
            String query = "SELECT * FROM employee";
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery(query);

            while (resultSet.next()) {
                int id = resultSet.getInt("id");
                String name = resultSet.getString("name");
                String email = resultSet.getString("email");
                String mobile = resultSet.getString("mobile");

                employeeList.add(new Employee(id, name, email, mobile));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @FXML
    protected void insertEmployeeData() {
        String name = employeeNameField.getText();
        String email = employeeEmailField.getText();
        String mobile = employeeMobileField.getText();

        String jdbcUrl = "jdbc:mysql://localhost:3306/lab3";
        String dbUser = "root";
        String dbPassword = "";

        try (Connection connection = DriverManager.getConnection(jdbcUrl, dbUser, dbPassword)) {
            String query = "INSERT INTO employee (name, email, mobile) VALUES (?, ?, ?)";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setString(1, name);
            statement.setString(2, email);
            statement.setString(3, mobile);

            statement.executeUpdate();
            fetchEmployeeData(); // Refresh table after insertion
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @FXML
    protected void updateEmployeeData() {
        int id = Integer.parseInt(employeeIdField.getText());
        String name = employeeNameField.getText();
        String email = employeeEmailField.getText();
        String mobile = employeeMobileField.getText();

        String jdbcUrl = "jdbc:mysql://localhost:3306/lab3";
        String dbUser = "root";
        String dbPassword = "";

        try (Connection connection = DriverManager.getConnection(jdbcUrl, dbUser, dbPassword)) {
            String query = "UPDATE employee SET name=?, email=?, mobile=? WHERE id=?";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setString(1, name);
            statement.setString(2, email);
            statement.setString(3, mobile);
            statement.setInt(4, id);

            statement.executeUpdate();
            fetchEmployeeData(); // Refresh table after update
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @FXML
    protected void deleteEmployeeData() {
        int id = Integer.parseInt(employeeIdField.getText());

        String jdbcUrl = "jdbc:mysql://localhost:3306/lab3";
        String dbUser = "root";
        String dbPassword = "";

        try (Connection connection = DriverManager.getConnection(jdbcUrl, dbUser, dbPassword)) {
            String query = "DELETE FROM employee WHERE id=?";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setInt(1, id);

            statement.executeUpdate();
            fetchEmployeeData(); // Refresh table after deletion
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @FXML
    protected void loadEmployeeData() {
        int id = Integer.parseInt(employeeIdField.getText());

        String jdbcUrl = "jdbc:mysql://localhost:3306/lab3";
        String dbUser = "root";
        String dbPassword = "";

        try (Connection connection = DriverManager.getConnection(jdbcUrl, dbUser, dbPassword)) {
            String query = "SELECT * FROM employee WHERE id=?";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setInt(1, id);

            ResultSet resultSet = statement.executeQuery();
            while (resultSet.next()) {
                String name = resultSet.getString("name");
                String email = resultSet.getString("email");
                String mobile = resultSet.getString("mobile");

                employeeNameField.setText(name);
                employeeEmailField.setText(email);
                employeeMobileField.setText(mobile);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
