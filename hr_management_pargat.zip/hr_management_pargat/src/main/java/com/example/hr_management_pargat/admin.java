package com.example.hr_management_pargat;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;

import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ResourceBundle;

public class adminController implements Initializable {

    @FXML
    private TableView<Admin> adminTable;
    @FXML
    private TableColumn<Admin, Integer> idColumn;
    @FXML
    private TableColumn<Admin, String> nameColumn;
    @FXML
    private TableColumn<Admin, String> emailColumn;
    @FXML
    private TableColumn<Admin, String> passwordColumn;
    @FXML
    private TextField idField;
    @FXML
    private TextField nameField;
    @FXML
    private TextField emailField;
    @FXML
    private TextField passwordField;
    @FXML
    private Button createButton;
    @FXML
    private Button updateButton;
    @FXML
    private Button deleteButton;
    @FXML
    private Button viewButton;
    @FXML
    private Button backButton;
    @FXML
    private Label welcomeText;

    private ObservableList<Admin> adminList = FXCollections.observableArrayList();

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        idColumn.setCellValueFactory(cellData -> cellData.getValue().idProperty().asObject());
        nameColumn.setCellValueFactory(cellData -> cellData.getValue().nameProperty());
        emailColumn.setCellValueFactory(cellData -> cellData.getValue().emailProperty());
        passwordColumn.setCellValueFactory(cellData -> cellData.getValue().passwordProperty());

        adminTable.setItems(adminList);
        fetchAdminData();
    }

    @FXML
    protected void fetchAdminData() {
        adminList.clear();
        String jdbcUrl = "jdbc:mysql://localhost:3306/lab3";
        String dbUser = "root";
        String dbPassword = "";
        try (Connection connection = DriverManager.getConnection(jdbcUrl, dbUser, dbPassword)) {
            String query = "SELECT * FROM admin";
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery(query);
            while (resultSet.next()) {
                int id = resultSet.getInt("id");
                String name = resultSet.getString("name");
                String email = resultSet.getString("email");
                String password = resultSet.getString("password");
                adminList.add(new Admin(id, name, email, password));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @FXML
    public void createAdmin() {
        String name = nameField.getText();
        String email = emailField.getText();
        String password = passwordField.getText();

        String jdbcUrl = "jdbc:mysql://localhost:3306/lab3";
        String dbUser = "root";
        String dbPassword = "";
        try (Connection connection = DriverManager.getConnection(jdbcUrl, dbUser, dbPassword)) {
            String query = "INSERT INTO admin (name, email, password) VALUES ('" + name + "','" + email + "','" + password + "')";
            Statement statement = connection.createStatement();
            statement.execute(query);
            fetchAdminData();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @FXML
    public void updateAdmin() {
        int id = Integer.parseInt(idField.getText());
        String name = nameField.getText();
        String email = emailField.getText();
        String password = passwordField.getText();

        String jdbcUrl = "jdbc:mysql://localhost:3306/lab3";
        String dbUser = "root";
        String dbPassword = "";
        try (Connection connection = DriverManager.getConnection(jdbcUrl, dbUser, dbPassword)) {
            String query = "UPDATE admin SET name='" + name + "', email='" + email + "', password='" + password + "' WHERE id=" + id;
            Statement statement = connection.createStatement();
            statement.executeUpdate(query);
            fetchAdminData();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @FXML
    public void deleteAdmin() {
        int id = Integer.parseInt(idField.getText());

        String jdbcUrl = "jdbc:mysql://localhost:3306/lab3";
        String dbUser = "root";
        String dbPassword = "";
        try (Connection connection = DriverManager.getConnection(jdbcUrl, dbUser, dbPassword)) {
            String query = "DELETE FROM admin WHERE id=" + id;
            Statement statement = connection.createStatement();
            statement.execute(query);
            fetchAdminData();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @FXML
    public void viewAdmin() {
        // Implement view functionality if needed
    }

    @FXML
    public void backToPreviousScene() {
        // Implement back functionality if needed
    }
}
